g++ 1905078_main.cpp -o demo -lglut -lGLU -lGL
./demo
