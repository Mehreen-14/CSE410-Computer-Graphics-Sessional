g++ 1905078_task1.cpp -o demo -lglut -lGLU -lGL
./demo
